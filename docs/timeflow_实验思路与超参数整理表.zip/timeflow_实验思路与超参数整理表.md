# TimeFlow 实验思路与超参数整理表

## 实验思路

当前这条实验主线可以概括为：

1. **先采样群体超参数**
   - 从预设范围内采样一组双黑洞群体超参数
   - 这些超参数决定红移分布、主质量分布、峰值成分、质量比等总体性质
   - 每一组超参数对应一个“群体模型”
   - 这一步主要依赖的相关库包括：
     - `gwfast.population.popdistributions`
     - `gwfast.population.POPmodels`
   - 其中：
     - 质量分布模型由 `gwfast` 的 population 模块提供
     - 红移分布模型也由 `gwfast` 的 population 模块提供

2. **由群体超参数生成 CBC 事件参数**
   - 在每组超参数约束下，进一步采样具体的 CBC 事件参数
   - 例如并合时间、主质量、次质量、距离等
   - 得到每组超参数下的一批离散事件
   - 这一步主要依赖：
     - `gwfast`
     - `jax / jax.numpy`
     - `astropy.cosmology.Planck18`
   - 其中：
     - `gwfast` 用来进行群体模型采样
     - `jax` 用来加速红移分布等函数计算
     - `astropy` 用来计算宇宙学距离，例如光度距离和微分共动体积

3. **生成双探测器信号并与噪声叠加**
   - 对每一组超参数文件，先得到这一组下所有 CBC 事件的参数：
     - `tc`：并合时刻
     - `m1, m2`
     - `z`
     - `dL`
     - `ra, dec`
     - `psi, phi_c, iota`
   - 然后把长时间观测切成多个固定长度的 frame。
   - 当前主线里常用设置是：
     - 采样率 `fs = 2048 Hz`
     - 每个 frame 时长 `duration = 2048 s`
   - 所以一个 frame 的采样点数是：

```text
2048 s × 2048 Hz = 4,194,304 points
```

   - 第 `jobNumber` 段 frame 的时间范围定义为：

```text
st = (jobNumber - 1) * duration
et = st + duration
```

   - 例如：
     - `jobNumber = 1` 对应 `[0, 2048]`
     - `jobNumber = 2` 对应 `[2048, 4096]`
     - `jobNumber = 3` 对应 `[4096, 6144]`

   - 对于每一个黑洞事件，不是只看它的并合时刻 `tc` 是否落在该 frame 内，而是检查它的波形是否与该时间窗有重叠。
   - 代码里会先估计事件从最低频率起始进入探测器带宽的时间 `t0`，然后用下面条件判断事件是否属于当前 frame：

```text
(tc > st) and (t0 < et)
```

   - 这表示：
     - 事件的并合不能发生在 frame 开始时间之前太早
     - 但只要事件的波形前段已经进入当前 frame，并且并合还没结束，它就会被放进这个 frame
   - 因此，一个事件被放入某个 frame，并不是简单靠 `tc` 单点判断，而是看它的整个波形时间支持区间是否与 `[st, et]` 有重叠。

   - 选出属于当前 frame 的事件后，会对每个事件做下面几步：
     1. 先根据源参考系质量和红移算出探测器系质量：

```text
m1_det = m1 * (1 + z)
m2_det = m2 * (1 + z)
```

     2. 用 `bilby` 的波形发生器生成该事件在当前 frame 长度下的时域波形 `plus / cross`
     3. 再根据事件的天区位置和偏振角，把波形投影到 H1 / L1 探测器
     4. 如果事件波形只部分落在当前 frame 内，就把超出 frame 的前后部分截掉，只保留和当前时间窗重叠的部分

   - 当前代码里还会对过强事件做筛选：
     - 先计算网络最优 SNR
     - 如果 `SNR >= 12`，就跳过这个事件，不注入
     - 只把较弱事件叠加进当前 frame
   - 这一步主要依赖：
     - `bilby`
     - `gwpy`
   - 其中：
     - `bilby.gw` 用来生成双黑洞波形、设置 H1/L1 探测器、计算探测器响应和 SNR、执行信号注入
     - `gwpy.timeseries` 用来把最终得到的 H1/L1 时域序列写成 `.gwf` frame 文件

   - 对每个 frame，会先初始化 H1 / L1 的零噪声时间序列，然后把该 frame 内所有保留下来的弱事件逐个注入：
     - 得到 H1 的纯信号 frame
     - 得到 L1 的纯信号 frame

   - 后续再与噪声 frame 做叠加，构成最终的双探测器输入数据。

4. **把长时间序列切分成训练样本**
   - 对叠加后的 frame 数据做切片
   - 每个切片保存为一个 `.npy` 样本
   - 每个样本包含：
     - 双探测器输入数据
     - 对应的群体超参数标签
   - 这一步主要依赖：
     - `gwpy`
     - `numpy`
   - 其中：
     - `gwpy` 负责读取 `.gwf` frame 数据
     - `numpy` 负责切片与保存 `.npy`

5. **构造模型输入表示**
   - 当前主要有两类输入方式：
   - 原始时域输入：
     - 直接使用 H1 / L1 双通道时域序列
     - 单样本输入近似为 `(2, 524288)`
   - 频域统计特征输入：
     - 先从双探测器时域数据提取：
       - `log(psd1)`
       - `log(psd2)`
       - `cpsd.real`
       - `cpsd.imag`
       - `coherence`
     - 再把这些频域特征作为网络输入
   - 如果使用频域统计特征输入，这一步主要依赖：
     - `scipy.signal.welch`
     - `scipy.signal.csd`
   - 其中：
     - `welch` 用来估计单探测器功率谱密度 `PSD`
     - `csd` 用来估计双探测器互功率谱密度 `CPSD`

6. **用条件归一化流学习后验**
   - 神经网络编码器先从输入中提取条件特征
   - 再由条件 normalizing flow 学习：

```text
p(theta | x)
```

其中：

- `x` 是 H1/L1 输入数据或频域统计特征
- `theta` 是待恢复的群体超参数标签
   - 这一步主要依赖：
     - `PyTorch`
     - `nflows`
   - 其中：
     - `PyTorch` 负责 CNN 编码器与整体训练
     - `nflows` 负责条件归一化流建模

7. **通过测试集后验质量判断模型能力**
   - 使用 `NLL` 评估联合后验密度学习情况
   - 使用 `cov68 / cov95` 判断区间校准情况
   - 使用 `ci68/r / ci95/r` 判断后验是否足够收窄
   - 这一步主要依赖：
     - `numpy`
     - `matplotlib`
     - `scipy.stats`
   - 其中：
     - `numpy` 用于分位数、覆盖率和区间宽度统计
     - `matplotlib` 用于画图
     - `scipy.stats.gaussian_kde` 用于单样本后验 KDE 可视化

当前实验的核心判断逻辑是：

- 如果提高模型复杂度后，后验明显收窄，说明模型表达能力曾是瓶颈
- 如果降到 2 维后后验仍然偏宽，说明问题不只是高维联合训练困难
- 如果改成频域统计特征后效果提升，说明原始时域输入方式可能不是最优表示

## 原始标签顺序

当前默认原始标签顺序是：

```text
[zp, alpha_z, beta_z, alpha_m, m_max, delta_m, m_min, lambda_peak, mu_m, sigma_m, beta_q]
```

## 超参数标签范围

下面范围主要对应 `draw_hyperparameters_v4.py` / `processed_data_superimposed/v1` 这条主线。

| 标签 | 范围 | 说明 |
|---|---|---|
| `zp` | `[0.85, 2.85]` | 独立采样 |
| `alpha_z` | 由 `zp` 线性决定，约 `[1.425, 4.425]` | 非独立采样 |
| `beta_z` | 由 `zp` 和 `alpha_z` 计算得到 | 非独立采样 |
| `alpha_m` | `[3.2, 3.6]` | 独立采样 |
| `m_max` | `100.0` | 固定 |
| `delta_m` | `[2.0, 10.0]` | 独立采样 |
| `m_min` | `2.0` | 固定 |
| `lambda_peak` | `[0.02, 0.06]` | 独立采样 |
| `mu_m` | `[33.2, 35.4]` | 独立采样 |
| `sigma_m` | `[3.52, 3.60]` | 独立采样 |
| `beta_q` | `[-5.0, 5.0]` | 独立采样 |

## 不同版本的训练标签

| 版本 | 训练标签 |
|---|---|
| `timeflow_v1_a` | `zp, alpha_m` |
| `timeflow_v1_b` | `zp, alpha_m` |

其中：

- `v1_a`：原始时域输入，2 通道，2 维标签
- `v1_b`：频域统计特征输入，5 通道，2 维标签

## CNN 超参数

下面这部分主要对应 `timeflow_v1_b` 当前主线。

| 超参数 | 当前常用值 | 作用 |
|---|---:|---|
| `in_channels` | `5` | 输入通道数；`v1_b` 频域特征版当前为 5 通道 |
| `CONTEXT_DIM` | `512` | 编码器最后输出给 flow 的条件特征维度 |
| `stem small kernel size` | `9` | 多尺度 stem 小卷积核分支 |
| `stem large kernel size` | `31` | 多尺度 stem 大卷积核分支 |
| `stem stride` | `2` | stem 下采样步长 |
| `Residual block channels` | `24→32→48→64→96→128→160→192` | CNN 各层通道宽度 |
| `Residual block kernel size` | `7` | 残差卷积块卷积核大小 |
| `Residual block stride` | 多数为 `2` | 各层下采样步长 |
| `dilation` | `1,1,2,2,4,4,8` | 扩张卷积率 |
| `GroupNorm groups` | `8` | 归一化分组数 |
| `SE reduction` | `8` | SE 模块通道压缩比例 |
| `pooling` | `avg + max + std` | 全局特征汇聚方式 |
| `activation` | `GELU` | 激活函数 |

## 归一化流超参数

| 超参数 | 当前常用值 | 作用 |
|---|---:|---|
| `FLOW_LAYERS` | `8` | flow 重复层数 |
| `FLOW_HIDDEN` | `256` | flow 内部隐藏层宽度 |
| `flow_bins` | `8` | spline 变换分段数 |
| `flow_tail_bound` | `3.0` | spline 尾部范围 |
| `num_blocks` | `2` | 每个 autoregressive transform 内部 block 数 |
| `use_residual_blocks` | `True` | flow 内部是否使用残差块 |
| `dropout_probability` | `0.0` | flow 内部 dropout |
| `base_distribution` | `StandardNormal` | flow 基础分布 |

## 其他训练超参数

| 超参数 | 当前常用值 | 作用 |
|---|---:|---|
| `BATCH_SIZE` | `16` | 每步训练样本数 |
| `EPOCHS` | `100` | 最大训练轮数 |
| `LEARNING_RATE` | `1e-4` | 学习率 |
| `WEIGHT_DECAY` | `1e-4` | 权重衰减 |
| `NUM_WORKERS` | `0` | DataLoader 并行加载进程数 |
| `VAL_FRACTION` | `0.2` | 验证集比例 |
| `TEST_FRACTION` | `0.1` | 测试集比例 |
| `TRAIN_SAMPLE_STEP` | `1` | 数据抽样步长 |
| `SEED` | `42` | 随机种子 |
| `AUTO_RESUME` | `True` | 是否断点续训 |
| `GPU_INDEX` | `0` | 使用哪张 GPU |
| `OVERFIT_DEBUG` | `False` | 是否启用小样本过拟合调试 |
| `OVERFIT_TRAIN_SAMPLES` | `64` | debug 模式下训练样本数 |
| `OVERFIT_VAL_SAMPLES` | `16` | debug 模式下验证样本数 |
| `OVERFIT_TEST_SAMPLES` | `16` | debug 模式下测试样本数 |
| `NUM_POSTERIOR_SAMPLES` | `800` 或 `1200` | 评估/画图时 posterior 采样数 |
